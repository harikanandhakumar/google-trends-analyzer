from pytrends.request import TrendReq
import pandas as pd

def get_trending_data(keyword: str, timeframe: str = 'today 5-y', geo: str = 'IN'):
    pytrends = TrendReq()
    pytrends.build_payload([keyword], cat=0, timeframe=timeframe, geo=geo)
    data = pytrends.interest_over_time()
    return data.drop(columns='isPartial') if 'isPartial' in data else data

def prepare_data_for_forecast(data, keyword):
    df = data.reset_index()[['date', keyword]]
    df.columns = ['ds', 'y']
    return df