import streamlit as st
from trend_fetcher import get_trending_data, prepare_data_for_forecast
from sentiment_analyzer import get_sentiment
from forecaster import forecast_trend
import plotly.graph_objects as go

st.title("📈 Google Trends Analyzer with Sentiment and Forecast")

keyword = st.text_input("Enter a topic or keyword:", "AI")

if st.button("Analyze"):
    data = get_trending_data(keyword)

    if not data.empty:
        st.line_chart(data[keyword])

        sentiment = get_sentiment(keyword)
        st.markdown(f"### Sentiment for '{keyword}': **{sentiment}**")

        df = prepare_data_for_forecast(data, keyword)
        forecast = forecast_trend(df)

        st.subheader("🔮 Forecast for Next 6 Months")
        fig = go.Figure()
        fig.add_trace(go.Scatter(x=forecast['ds'], y=forecast['yhat'], name='Forecast'))
        fig.add_trace(go.Scatter(x=df['ds'], y=df['y'], name='Historical'))
        st.plotly_chart(fig)
    else:
        st.warning("No data found for this keyword.")